var dog = require('./mathlibs')();
dog.add(3,4);
dog.multiply(3,4);
dog.square(4);
dog.random(10,20);