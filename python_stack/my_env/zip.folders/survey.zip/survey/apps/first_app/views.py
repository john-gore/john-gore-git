from django.shortcuts import render, HttpResponse, redirect

def index(request):
    response = "Lets rock!"
    
    return render(request,'page.html')

def create(request):
    if request.method == "GET":
        request.session['count'] ==0
    elif request.method == "POST":
        request.session['count'] += 1
        print "*"*50
        print request.POST
        print request.POST['full_name']
        print request.POST['dojo_location']
        print request.POST['fav_lang']
        print request.POST['comment']
        unique_id = request.POST['full_name']
        dojo = request.POST['dojo_location']
        fav = request.POST['fav_lang']
        comment = request.POST['comment']
        context = {
        "somekey": unique_id,
        "dojo": dojo,
        "fav": fav,
        "comment": comment,
        "number": request.session['count']
        }
        return render(request, 'results.html', context)
        
# Create your views here.
