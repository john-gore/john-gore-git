from django.shortcuts import render, HttpResponse, redirect
def index(request):
    response = "Hi there!!"
    return HttpResponse(response)

# Create your views here.
