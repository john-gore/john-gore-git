from django.shortcuts import render, HttpResponse, redirect
from django.core.urlresolvers import reverse
from .models import Blog
from django.contrib import messages
def index(request):
    all_users = { 'all_users': Blog.objects.all().values() }
    print Blog.objects.all()
    return render(request, 'landingpage.html', context = all_users)
def new(request):
    return render(request, 'adduser.html')
def addnew(request):
    print 'Working for adding new'
    print request.POST
    request.POST['first_name']
    request.POST['last_name']
    request.POST['email']
    print request.POST['first_name']
    print request.POST['last_name']
    print request.POST['email']
    Blog.objects.create(first_name=request.POST['first_name'], last_name=request.POST['last_name'], email=request.POST['email'] )
    return render(request, 'adduser.html')
def show(request):
    return render(request, 'showuser.html')
def edit(request):
    return render(request, 'edituser.html')
def user_edit(request):
    request.POST['first_name']
    request.POST['last_name']
    request.POST['email']
    print request.POST['first_name']
    print request.POST['last_name']
    print request.POST['email']
    return redirect('/edit')
def delete(request):
    Blog.objects.get(id=id).delete()
    return render(request, 'edituser.html')
# Create your views here.
