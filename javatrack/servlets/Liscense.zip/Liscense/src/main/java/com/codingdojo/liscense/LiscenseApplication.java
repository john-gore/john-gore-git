package com.codingdojo.liscense;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LiscenseApplication {

	public static void main(String[] args) {
		SpringApplication.run(LiscenseApplication.class, args);
	}
}
