package com.codingdojo.javabelt2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Javabelt2Application {

	public static void main(String[] args) {
		SpringApplication.run(Javabelt2Application.class, args);
	}
}
